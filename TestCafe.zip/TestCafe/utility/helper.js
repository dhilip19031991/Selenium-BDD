import { Selector } from 'testcafe'

let accNumPerson;
let accNumCompany;

export function generateRandomString(l) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let res = '';
    for (let i = 0; i < l; i++) {
        let randomString = chars.charAt(Math.floor(Math.random() * chars.length));
        res = res + randomString;
    }
    return res;
}

export function generateRandomNumber(targetLength) {
    const chars = '0123456789';
    let res = '';
    for (let i = 0; i < targetLength; i++) {
        let randonNumber = chars.charAt(Math.floor(Math.random() * chars.length));
        res = res + randonNumber;
    }
    return res;
}

export async function getAccNum() {
    return await Selector(asp.accNoTxt).innerText;
}

export async function setAccNumPerson(accNoPerson) {
    accNumPerson = accNoPerson;
}
export async function getAccNumPerson() {
    return accNumPerson;
}

export async function setAccNumCompany(accNoCompany) {
    accNumCompany = accNoCompany;
}
export async function getAccNumCompany() {
    return accNumCompany;
}