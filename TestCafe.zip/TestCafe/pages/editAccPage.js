import { Selector } from "testcafe";

class EditAccPage{
    constructor(){
        this.address1 = Selector('[id="EditAccountPopup:EditAccountScreen:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressLine1-inputEl"]');
        this.updateBtn = Selector('[id="EditAccountPopup:EditAccountScreen:Update-btnInnerEl"]');
    }
}

export default new EditAccPage();