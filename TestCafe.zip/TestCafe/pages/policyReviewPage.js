import { Selector } from "testcafe";

class PolicyReviewPage {
    constructor() {
        this.quoteBtn = Selector('[id="SubmissionWizard:SubmissionWizard_PolicyReviewScreen:JobWizardToolbarButtonSet:QuoteOrReview-btnInnerEl"]');
    }
}

export default new PolicyReviewPage();