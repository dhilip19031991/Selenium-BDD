import { Selector } from "testcafe";

class LOBPage{
    constructor(){
        this.btnSelectPA = Selector('[id="NewSubmission:NewSubmissionScreen:ProductOffersDV:ProductSelectionLV:7:addSubmission"]');
    }
}

export default new LOBPage();