import { Selector } from "testcafe";

class PolicyInfoPage {
    constructor() {
        this.nextBtn = Selector('[id="SubmissionWizard:Next-btnInnerEl"]');
    }
}

export default new PolicyInfoPage();