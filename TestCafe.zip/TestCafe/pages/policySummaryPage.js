import { Selector } from "testcafe";

class PolicySummaryPage {
    constructor() {
        this.policyNo = Selector('[id="PolicyFile_Summary:Policy_SummaryScreen:Policy_Summary_PolicyDV:PolicyNumber-inputEl"]');
    }
}

export default new PolicySummaryPage();