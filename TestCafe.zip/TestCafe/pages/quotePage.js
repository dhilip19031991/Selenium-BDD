import { Selector } from "testcafe";
import xpath from '../utility/xpath-selector.js';

class QuotePage {
    constructor() {
        this.bindOptionsDD = Selector('[id="SubmissionWizard:SubmissionWizard_QuoteScreen:JobWizardToolbarButtonSet:BindOptions-btnInnerEl"]');
        this.issuePolicyBtn = Selector('[id="SubmissionWizard:SubmissionWizard_QuoteScreen:JobWizardToolbarButtonSet:BindOptions:BindAndIssue-textEl"]');
        this.PACoveragesBtn = Selector(xpath('//td[@id="SubmissionWizard:LOBWizardStepGroup:PALine"]//span[text()="PA Coverages"]'));
        this.okBtn = Selector('[id="button-1005-btnInnerEl"]');
    }
}

export default new QuotePage();