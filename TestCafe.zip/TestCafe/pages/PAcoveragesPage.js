import { Selector } from "testcafe";
import xpath from '../utility/xpath-selector.js';

class PACoveragesPage {
    constructor() {
        this.chkBoxCollision = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PersonalAutoScreen:PAPerVehiclePanelSet:VehicleCoverageDetailsCV:PersonalAuto_VehicleCoverageDetailDV:1:CoverageInputSet:CovPatternInputGroup:_checkbox"]');
        this.txtCD = Selector(xpath('//span[text()="Collision Deductible"]'));
        this.valueCD = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PersonalAutoScreen:PAPerVehiclePanelSet:VehicleCoverageDetailsCV:PersonalAuto_VehicleCoverageDetailDV:1:CoverageInputSet:CovPatternInputGroup:0:CovTermInputSet:OptionTermInput-inputEl"]');
        this.valueND = Selector(xpath('//li[text()="No Deductible"]'));
        this.value250 = Selector(xpath('//li[text()="250"]'));
        this.value500 = Selector(xpath('//li[text()="500"]'));
        this.value1000 = Selector(xpath('//li[text()="1,000"]'));
        this.chkBoxTL = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PersonalAutoScreen:PAPerVehiclePanelSet:VehicleCoverageDetailsCV:PersonalAuto_VehicleCoverageDetailDV:2:CoverageInputSet:CovPatternInputGroup:_checkbox"]');
        this.txtOfTL = Selector(xpath('//span[text()="Towing and Labor Limit"]'));
        this.valueTLDD = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PersonalAutoScreen:PAPerVehiclePanelSet:VehicleCoverageDetailsCV:PersonalAuto_VehicleCoverageDetailDV:2:CoverageInputSet:CovPatternInputGroup:0:CovTermInputSet:OptionTermInput-inputEl"]');
        this.value25 = Selector(xpath('//li[text()="25"]'));
        this.value50 = Selector(xpath('//li[text()="50"]'));
        this.value75 = Selector(xpath('//li[text()="75"]'));
        this.value100 = Selector(xpath('//li[text()="100"]'));
        this.editPTBtn = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PersonalAutoScreen:JobWizardToolbarButtonSet:EditPolicy-btnInnerEl"]');
        this.okBtn = Selector(xpath('//span[text()="OK"]'));
        this.quoteBtn = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PersonalAutoScreen:JobWizardToolbarButtonSet:QuoteOrReview-btnInnerEl"]');
        this.nextBtn = Selector('[id="SubmissionWizard:Next-btnInnerEl"]');
        this.Coveragestab = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PersonalAutoScreen:CoveragesTab-btnInnerEl"]');
        this.AdditionalCoverage = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PersonalAutoScreen:AdditionalCoveragesTab-btnInnerEl"]');
        this.ExclusionsandConditions = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PersonalAutoScreen:exclusionsAndConditionsCardTab-btnInnerEl"]');

    }
}

export default new PACoveragesPage();