import { Selector } from 'testcafe'
import xpath from '../utility/xpath-selector.js'

class NewDriver{
    constructor(){
        this.NDAccidentPL = Selector(xpath('//td[@class="x-grid-cell x-grid-td x-grid-cell-gridcolumn-1513 g-cell-edit"]'));
        this.NDAccidentPLValue = Selector(xpath('//div[@id="boundlist-1542-listWrap"])//li[text()="0"]'));
        this.NDAccidentAL = Selector ('[id="ext-element-561"]');
        this.NDAccidentALValue = Selector(xpath('//li[text()="0"]'));
        this.NDViolationPL = Selector ('[class="x-grid-cell x-grid-td x-grid-cell-gridcolumn-1631  g-cell-edit"]');
        this.NDViolationPLValue = Selector(xpath('//li[text()="0"]'));
        this.NDViolationAL = Selector ('[class="x-grid-cell x-grid-td x-grid-cell-gridcolumn-1632  g-cell-edit"]');
        this.NDViolationALValue = Selector(xpath('//li[text()="0"]'));
        this.LicenseYear = Selector ('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriverDetailsCV:0:PolicyContactRolePanelSet:PolicyDriverInfoDV:yearlicensed-inputEl"]');
        this.OkBtn = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:Update-btnInnerEl"]');
        this.addressTypeHome = Selector(xpath('//li[text()="Home"]'));
        this.driverLicenseState = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:NewPolicyContactRoleDetailsCV:PolicyContactDetailsDV:LicenseInputSet:LicenseState-inputEl"]');
        this.driverLicenseStateCalifornia = Selector (xpath('//li[text()="California"]'));
        this.driverDob = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:NewPolicyContactRoleDetailsCV:PolicyContactDetailsDV:PolicyContactRoleNameInputSet:DateOfBirth-inputEl"]');
        this.License = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:NewPolicyContactRoleDetailsCV:PolicyContactDetailsDV:LicenseInputSet:LicenseNumber-inputEl"]');
        this.firstname = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:NewPolicyContactRoleDetailsCV:PolicyContactDetailsDV:PolicyContactRoleNameInputSet:GlobalPersonNameInputSet:FirstName-inputEl"]');
        this.lastname = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:NewPolicyContactRoleDetailsCV:PolicyContactDetailsDV:PolicyContactRoleNameInputSet:GlobalPersonNameInputSet:LastName-inputEl"]');
        this.Address1 = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:NewPolicyContactRoleDetailsCV:PolicyContactDetailsDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressLine1-inputEl"]');
        this.City = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:NewPolicyContactRoleDetailsCV:PolicyContactDetailsDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:City-inputEl"]');
        this.StateDD = Selector (xpath('//li[text()="California"]'));
        this.State = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:NewPolicyContactRoleDetailsCV:PolicyContactDetailsDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:State-trigger-picker"]');
        this.ZipCode = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:NewPolicyContactRoleDetailsCV:PolicyContactDetailsDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:PostalCode-inputEl"]');
        this.AddressType = Selector ('[id="NewPolicyDriverPopup:ContactDetailScreen:NewPolicyContactRoleDetailsCV:PolicyContactDetailsDV:AddressType-inputEl"]');
    }}
export default new NewDriver();