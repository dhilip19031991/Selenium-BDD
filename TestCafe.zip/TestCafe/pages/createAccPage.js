import { Selector } from 'testcafe'
import xpath from '../utility/xpath-selector.js'

class CreateAccPage {
    constructor() {
        this.firstname = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:GlobalPersonNameInputSet:FirstName-inputEl"]');
        this.lastname = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:GlobalPersonNameInputSet:LastName-inputEl"]');
        this.city = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:City-inputEl"]');
        this.producerCode = Selector(xpath('//li[text()="Standard Code Internal Producer Code - 1"]'));
        this.stateDD = Selector(xpath('//li[text()="California"]'));
        this.state = Selector(xpath('//div[@id="CreateAccount:CreateAccountScreen:CreateAccountDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:State-trigger-picker"]'));
        this.ProducerSelect = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:ProducerSelectionInputSet:Producer-inputEl"]');
        this.searchIcon = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:ProducerSelectionInputSet:Producer:SelectOrganization"]');
        this.successMsg = Selector('[id="CreateAccount:CreateAccountScreen:ttlBar"]');
        this.zipCode = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:PostalCode-inputEl"]');
        this.address1 = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressLine1-inputEl"]');
        this.addressTypeDD = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:AddressType-inputEl"]');
        this.addressType = Selector(xpath('//li[text()="Home"]'));
        this.orgDD = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:ProducerSelectionInputSet:Producer:SelectOrganization"]');
        this.pcDDIcon = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:ProducerSelectionInputSet:ProducerCode-inputEl"]');
        this.producerCode = Selector(xpath('//li[text()="Standard Code Internal Producer Code - 1"]'));
        this.updateBtn = Selector('[id="CreateAccount:CreateAccountScreen:Update-btnInnerEl"]');
    }
}

export default new CreateAccPage();