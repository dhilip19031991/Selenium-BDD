import { Selector } from "testcafe";

class AccInfoPage {
    constructor() {
        this.successMsg = Selector('[id="NewAccount:NewAccountScreen:ttlBar"]');
        this.companyName = Selector('[id="NewAccount:NewAccountScreen:NewAccountSearchDV:GlobalContactNameInputSet:Name-inputEl"]');
        this.firstName = Selector('[id="NewAccount:NewAccountScreen:NewAccountSearchDV:GlobalPersonNameInputSet:FirstName-inputEl"]');
        this.lastName = Selector('[id="NewAccount:NewAccountScreen:NewAccountSearchDV:GlobalPersonNameInputSet:LastName-inputEl"]');
        this.searchBtn = Selector('[id="NewAccount:NewAccountScreen:NewAccountSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search"]');
        this.checkPoint = Selector('[class="message"]');
        this.createNewAcc = Selector('[id="NewAccount:NewAccountScreen:NewAccountButton-btnInnerEl"]');
        this.personBtn = Selector('[id="NewAccount:NewAccountScreen:NewAccountButton:NewAccount_Person-textEl"]');
        this.companyBtn = Selector('[id="NewAccount:NewAccountScreen:NewAccountButton:NewAccount_Company-textEl"]');
    }
}

export default new AccInfoPage();