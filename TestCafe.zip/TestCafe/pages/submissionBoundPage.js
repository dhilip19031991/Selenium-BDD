import { Selector } from "testcafe";

class SubmissionBoundPage {
    constructor() {
        
        this.viewPolicy = Selector('[id="JobComplete:JobCompleteScreen:JobCompleteDV:ViewPolicy-inputEl"]');
    }
}

export default new SubmissionBoundPage();