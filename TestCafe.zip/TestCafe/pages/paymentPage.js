import { Selector } from "testcafe";

  class Payment{
    constructor() 
{
    this.popupOk = Selector('[id="button-1005-btnInnerEl"]');
    this.BindOptions = Selector('[id="SubmissionWizard:SubmissionWizard_PaymentScreen:JobWizardBillingToolbarButtonSet:BindOptions-btnInnerEl"]');
    this.IssuePolicy = Selector('[id="SubmissionWizard:SubmissionWizard_PaymentScreen:JobWizardBillingToolbarButtonSet:BindOptions:BindAndIssue-textEl"]');
}}
 
export default new Payment();