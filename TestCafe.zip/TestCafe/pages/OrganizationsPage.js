import { Selector } from "testcafe";

class Organization{
    constructor(){
        this.OrgName = Selector ('[id="OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchDV:GlobalContactNameInputSet:Name-inputEl"]');
        this.SearchBtn = Selector ('[id="OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search"]');
        this.OrgSelect = Selector ('[id="OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchResultsLV:0:_Select"]');
    }
}
export default new Organization();