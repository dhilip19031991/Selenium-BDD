import { Selector } from "testcafe";
import xpath from '../utility/xpath-selector.js'

class NewAccHolderPage{
    constructor(){
        this.firstName = Selector('[id="ChangeAccountHolderToNewContactPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:GlobalPersonNameInputSet:FirstName-inputEl"]');
        this.lastName = Selector('[id="ChangeAccountHolderToNewContactPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:ContactNameInputSet:GlobalPersonNameInputSet:LastName-inputEl"]');
        this.zipcode = Selector('[id="ChangeAccountHolderToNewContactPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:PostalCode-inputEl"]');
        this.address1 = Selector('[id="ChangeAccountHolderToNewContactPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressLine1-inputEl"]');
        this.addressTypeDD = Selector('[id="ChangeAccountHolderToNewContactPopup:ContactDetailScreen:AccountContactCV:AccountContactDV:AddressType-inputEl"]');
        this.addressType = Selector(xpath('//li[text()="Home"]'));
        this.updateBtn = Selector('[id="ChangeAccountHolderToNewContactPopup:ContactDetailScreen:Update-btnInnerEl"]');
    }
}

export default new NewAccHolderPage();