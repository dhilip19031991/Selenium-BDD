import { Selector } from "testcafe";
import xpath from "../utility/xpath-selector";

class CommissionPlan {
    constructor() {
        this.name = Selector('id="NewCommissionPlan:CommissionPlanDetailScreen:CommissionPlanDetailPanelSet:Name-inputEl"');
        this.primary = Selector('id="NewCommissionPlan:CommissionPlanDetailScreen:CommissionPlanDetailPanelSet:CommissionSubPlanDetailCV:0:Rate-inputEl"');
        this.secondary = Selector('id="NewCommissionPlan:CommissionPlanDetailScreen:CommissionPlanDetailPanelSet:CommissionSubPlanDetailCV:1:Rate-inputEl"');
        this.referrer = Selector('id="NewCommissionPlan:CommissionPlanDetailScreen:CommissionPlanDetailPanelSet:CommissionSubPlanDetailCV:2:Rate-inputEl"');
        this.eancommissiondrpdwn = Selector('id="NewCommissionPlan:CommissionPlanDetailScreen:CommissionPlanDetailPanelSet:CommissionSubPlanDetailCV:CommissionsPayable-inputEl"');
        this.eanCommissionOption = Selector(xpath('//li[text()="On Binding"]'));
        this.UpdtBtn = Selector('id="NewCommissionPlan:CommissionPlanDetailScreen:Update-btnInnerEl"')
    }
}
export default new CommissionPlan();