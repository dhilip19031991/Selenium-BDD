import { Selector } from "testcafe";
import xpath from '../utility/xpath-selector.js'

class DriversPage {
    constructor() {
        this.newperson = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriversLV_tb:AddDriver:0:ContactType-itemEl"]');        
        this.licenseStateCalifornia = Selector(xpath('//li[text()="California"]'));
        this.rolesTab = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriverDetailsCV:RolesCardTab-btnInnerEl"]');
        this.yearFirstLicensed = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriverDetailsCV:1:PolicyContactRolePanelSet:PolicyDriverInfoDV:yearlicensed-inputEl"]');
        this.addBtn = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriversLV_tb:AddDriver-btnInnerEl"]');
        this.existingDriver = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriversLV_tb:AddDriver:AddExistingContact-textEl"]');
        this.accHolder = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriversLV_tb:AddDriver:AddExistingContact:0:UnassignedDriver-textEl"]');
        this.dob = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriverDetailsCV:PolicyContactDetailsDV:PolicyContactRoleNameInputSet:DateOfBirth-inputEl"]');
        this.licenseNo = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriverDetailsCV:PolicyContactDetailsDV:LicenseInputSet:LicenseNumber-inputEl"]');
        this.licenseStateDD = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriverDetailsCV:PolicyContactDetailsDV:LicenseInputSet:LicenseState-trigger-picker"]');
        this.licenseState = Selector(xpath('//li[text()="Arizona"]'));
        this.rolesTab = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriverDetailsCV:RolesCardTab-btnInnerEl"]');
        this.yearFirstLicensed = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriverDetailsCV:1:PolicyContactRolePanelSet:PolicyDriverInfoDV:yearlicensed-inputEl"]');
        this.accidentsNoPL = Selector(xpath('(//div[@id="centerPanel"]//tr//td//div//table[@class="x-grid-item"]//div)[2]'));
        this.violationsNoPL = Selector(xpath('(//div[@id="centerPanel"]//tr//td//div//table[@class="x-grid-item x-grid-item-alt"]//div)[2]'));
        this.accidentsNoAL = Selector(xpath('(//div[@id="centerPanel"]//tr//td//div//table[@class="x-grid-item"]//div)[3]'));
        this.violationsNoAL = Selector(xpath('(//div[@id="centerPanel"]//tr//td//div//table[@class="x-grid-item x-grid-item-alt"]//div)[3]'));
        this.accidentsNoPLValue = Selector(xpath('//li[text()="0"]'));
        this.violationsNoPLValue = Selector(xpath('//div[@class="x-boundlist x-boundlist-floating x-layer x-boundlist-default x-border-box x-boundlist-above"]//li[text()="0"]'));
        this.accidentsNoALValue = Selector(xpath('//div[@class="x-boundlist x-boundlist-floating x-layer x-boundlist-default x-border-box x-boundlist-above"]//li[text()="0"]'));
        this.violationsNoALValue = Selector(xpath('//div[@class="x-boundlist x-boundlist-floating x-layer x-boundlist-default x-border-box x-boundlist-above"]//li[text()="0"]'));
        this.radioBtn = Selector(xpath('//img[@class="x-grid-checkcolumn "]'));
        this.retrieveMVRBtn = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriversLV_tb:RetrieveMVRButton-btnInnerEl"]');
        this.MVRStatus = Selector(xpath('(//div[@id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PADriversScreen:PADriversPanelSet:DriversListDetailPanel:DriversLV-body"]//table//div)[5]'));
        this.nextBtn = Selector('[id="SubmissionWizard:Next-btnInnerEl"]');
    }
}

export default new DriversPage();