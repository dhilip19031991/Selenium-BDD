import { Selector } from "testcafe";
import xpath from "../utility/xpath-selector";

class InstallmentTreatment {
    constructor() {
        this.maxinstallments = Selector('id="NewPaymentPlanWizard:NewPaymentPlan_SecondStepScreen:InstallmentTreatment:InstallmentTreatmentInputSet:MaximumNumberOfInstallments-inputEl"');
        this.downpayment = Selector('id="NewPaymentPlanWizard:NewPaymentPlan_SecondStepScreen:InstallmentTreatment:InstallmentTreatmentInputSet:DownPaymentPercent-inputEl"');
        this.finish = Selector('id="NewPaymentPlanWizard:Finish-btnInnerEl"');
        this.Summary_Name = Selector('id="NewPaymentPlanWizard:NewPaymentPlan_SecondStepScreen:NewPaymentPlan_SummaryDV:Name-inputEl"');
        this.Summary_PayInterval = Selector('id="NewPaymentPlanWizard:NewPaymentPlan_SecondStepScreen:NewPaymentPlan_SummaryDV:PaymentInterval-inputEl"');
        this.PP_Title = Selector('id="PaymentPlanDetail:PaymentPlanDetailScreen:ttlBar"');
        this.invoiced = Selector('id="NewPaymentPlanWizard:NewPaymentPlan_SecondStepScreen:InstallmentTreatment:InstallmentTreatmentInputSet:DaysFromEventToDownPayment-inputEl"')
    }   
}
export default new InstallmentTreatment();