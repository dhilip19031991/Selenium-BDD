import { Selector } from "testcafe";

class OrgPage {
    constructor() {
        this.successMsg = Selector('[id="OrganizationSearchPopup:OrganizationSearchPopupScreen:ttlBar"]');
        this.orgName = Selector('[id="OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchDV:GlobalContactNameInputSet:Name-inputEl"]');
        this.searchBtn = Selector('[id="OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search"]');
        this.selectBtn = Selector('[id="OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchResultsLV:0:_Select"]');
    }
}

export default new OrgPage();