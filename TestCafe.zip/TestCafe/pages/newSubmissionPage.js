import { Selector } from "testcafe";

class NewSubmissionPage {
    constructor() {
        this.PrdSelect = Selector('[id="NewSubmission:NewSubmissionScreen:ProductOffersDV:ProductSelectionLV:7:addSubmission"]');
        this.accNum = Selector('[id="NewSubmission:NewSubmissionScreen:SelectAccountAndProducerDV:Account-inputEl"]');
        this.org = Selector('[id="NewSubmission:NewSubmissionScreen:SelectAccountAndProducerDV:ProducerSelectionInputSet:Producer-inputEl"]');
        this.accName = Selector('[id="NewSubmission:NewSubmissionScreen:SelectAccountAndProducerDV:AccountName-inputEl"]');
    }
}

export default new NewSubmissionPage();