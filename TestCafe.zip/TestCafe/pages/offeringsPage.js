import { Selector } from "testcafe";
import xpath from "../utility/xpath-selector.js";

class OfferingsPage {
    constructor() {
        this.BasicOfferSelection = Selector(xpath('//li[text() ="Basic Program"]'));
        this.offeringsDD = Selector('[id="SubmissionWizard:OfferingScreen:OfferingSelection-inputEl"]');
        this.offeringsType = Selector(xpath('//li[text()="Basic Program"]'));
        this.nextBtn = Selector('[id="SubmissionWizard:Next-btnInnerEl"]');
    }
}

export default new OfferingsPage();