import { Selector } from "testcafe";

class LoginPage {
    constructor() {
        this.userName = Selector('[id="Login:LoginScreen:LoginDV:username-inputEl"]');
        this.password = Selector('[id="Login:LoginScreen:LoginDV:password-inputEl"]');
        this.loginBtn = Selector('[id="Login:LoginScreen:LoginDV:submit-btnInnerEl"]');
    }
}

export default new LoginPage();