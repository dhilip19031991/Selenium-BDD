import { Selector } from "testcafe";
import xpath from '../utility/xpath-selector.js'

class NewEmailPage {
    constructor() {
        this.name = Selector(xpath('(//tbody[@id="EmailWorksheet-tbody"]//div[@class="x-grid-item-container"]//td//div)[2]'));
        this.email = Selector(xpath('(//tbody[@id="EmailWorksheet-tbody"]//div[@class="x-grid-item-container"]//td//div)[3]')); 
        this.subject = Selector('[id="EmailWorksheet:CreateEmailScreen:Subject-inputEl"]');
        this.body = Selector('[id="EmailWorksheet:CreateEmailScreen:Body-inputEl"]');
        this.sendBtn = Selector('[id="EmailWorksheet:CreateEmailScreen:SendEmailButton-btnInnerEl"]');
    }
}

export default new NewEmailPage();  