import { Selector } from "testcafe";

  class AccountCreation{
    constructor() 
{
    this.clickSubmitBtn = Selector('[id="Login:LoginScreen:LoginDV:submit-btnInnerEl"]'),
    this.clickActionsTab = Selector('[id="Desktop:DesktopMenuActions-btnEl"]'),
    this.clickNewAccountBtn = Selector('[id="Desktop:DesktopMenuActions:DesktopMenuActions_Create:DesktopMenuActions_NewAccount-textEl"]'),
    this.clickCompanyName = Selector('[id="NewAccount:NewAccountScreen:NewAccountSearchDV:GlobalContactNameInputSet:Name-inputEl"]'),
    this.clickSearchButton = Selector('[id="NewAccount:NewAccountScreen:NewAccountSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search"]'),
    this.clickCreateNewAccountBtn = Selector('[id="NewAccount\:NewAccountScreen\:NewAccountButton-btnInnerEl"]'),
    this.clickPerson = Selector('[id="NewAccount:NewAccountScreen:NewAccountButton:NewAccount_Person-itemEl"]'),
    this.clickUpdateBtn = Selector('[id="CreateAccount:CreateAccountScreen:Update-btnInnerEl"]'),
    this.typeFirstName = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:GlobalPersonNameInputSet:FirstName-inputEl"]'),
    this.typeLastName = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:CreateAccountContactInputSet:GlobalPersonNameInputSet:LastName-inputEl"]'),
    this.typeAddress = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:AddressLine1-inputEl"]'),
    this.typeCity = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:City-inputEl"]'),
    this.clickState = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:State-inputEl"]'),
    this.typeZipCode = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:AddressInputSet:globalAddressContainer:GlobalAddressInputSet:PostalCode-inputEl"]'),
    this.clickAdressType = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:AddressType-inputEl"]'),
    this.clickSearchBtn = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:ProducerSelectionInputSet:Producer:SelectOrganization"]'),
    this.typeIntoSearch = Selector('[id="OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchDV:GlobalContactNameInputSet:Name-inputEl"]'),
    this.clickSearch = Selector('[class="bigButton"]'),
    this.clickSelectBtn = Selector('[id="OrganizationSearchPopup:OrganizationSearchPopupScreen:OrganizationSearchResultsLV:0:_Select"]'),
    this.clickProducerCode = Selector('[id="CreateAccount:CreateAccountScreen:CreateAccountDV:ProducerSelectionInputSet:ProducerCode-inputEl"]'),
    this.getAccountNumber = Selector('[id="AccountFile_Summary\:AccountFile_SummaryScreen\:AccountFile_Summary_BasicInfoDV\:AccountNumber-inputEl"]')
    }
  }
 export default new AccountCreation();