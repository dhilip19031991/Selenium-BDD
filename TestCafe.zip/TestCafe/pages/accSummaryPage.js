import { Selector } from "testcafe";
import xpath from "../utility/xpath-selector";

class AccSummaryPage {
    constructor() {
        this.mergeOkPopup = Selector(xpath('//span[@class="x-btn-button x-btn-button-default-small x-btn-text    x-btn-button-center "]'));
        this.mergeaccountBtn = Selector(xpath('//span[@id="AccountFile_MergeAccountsSelection:MergeAccounts-btnEl"]'));
        this.infoText = Selector('[id="AccountFile_MergeAccountsSelection:mergeAccountsAlert"]');
        this.accountText = Selector('[id="AccountFile_MergeAccountsSelection:mergeAccountRemovalAlert"]');
        this.accountRemoved = Selector('[id="AccountFile_MergeAccountsSelection:mergeAccountRemovalAlert"]');
        this.searchBtn = Selector(xpath('//a[@id="AccountFile_AccountSearch:OtherAccountSearchScreen:AccountSearchDV:SearchAndResetInputSet:SearchLinksInputSet:Search"]'));
        this.selectPolicy = Selector('[id="AccountFile_AccountSearch:OtherAccountSearchScreen:OtherAccountSearchResultsLV:0:Select"]');
        this.accNumTxtBx = Selector('[id="AccountFile_AccountSearch:OtherAccountSearchScreen:AccountSearchDV:AccountNumber-inputEl"]');
        this.mergeToAccount = Selector('[id="AccountFile:AccountFileMenuActions:AccountFileMenuActions_MergeAccounts-textEl"]');
        this.accNoTxt = Selector('[id="AccountFile_Summary:AccountFile_SummaryScreen:AccountFile_Summary_BasicInfoDV:AccountNumber-inputEl"]');
        this.actions = Selector('[id="AccountFile:AccountFileMenuActions-btnInnerEl"]');
        this.newSubmission = Selector('[id="AccountFile:AccountFileMenuActions:AccountFileMenuActions_Create:AccountFileMenuActions_NewSubmission-textEl"]');
        this.newNote = Selector('[id="AccountFile:AccountFileMenuActions:AccountFileMenuActions_Create:AccountFileMenuActions_NewNote-textEl"]');
        this.newEmail = Selector('[id="AccountFile:AccountFileMenuActions:AccountFileMenuActions_Create:AccountFileMenuActions_NewEmail-textEl"]');
        this.editAccBtn = Selector('[id="AccountFile_Summary:AccountFile_SummaryScreen:EditAccount-btnInnerEl"]');
        this.changeAccHolderBtn = Selector('[id="AccountFile_Summary:AccountFile_SummaryScreen:ChangeAccountHolder-btnInnerEl"]');
        this.newPersonBtn = Selector('[id="AccountFile_Summary:AccountFile_SummaryScreen:ChangeAccountHolder:ChangeToPerson-textEl"]');
        this.withdrawAcc = Selector('[id="AccountFile:AccountFileMenuActions:AccountFileMenuActions_WithdrawAccount-textEl"]');
        this.reopenAcc = Selector('[id="AccountFile:AccountFileMenuActions:AccountFileMenuActions_ReopenAccount-textEl"]');
        this.accStatus = ('[id="AccountFile_Summary:AccountFile_SummaryScreen:AccountFile_Summary_BasicInfoDV:AccountStatus-inputEl"]');
    }
}

export default new AccSummaryPage();