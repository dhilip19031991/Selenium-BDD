import { Selector } from "testcafe";

class DashboardPage {
    constructor() {
        this.successMsg = Selector('[id="DesktopActivities:DesktopActivitiesScreen:0"]');
        this.actionsTab = Selector('[id="Desktop:DesktopMenuActions-btnInnerEl"]');
        this.newAccount = Selector('[id="Desktop:DesktopMenuActions:DesktopMenuActions_Create:DesktopMenuActions_NewAccount-textEl"]');
        this.newSubmission = Selector('[id="Desktop:DesktopMenuActions:DesktopMenuActions_Create:DesktopMenuActions_NewSubmission-textEl"]');
    }
}

export default new DashboardPage();