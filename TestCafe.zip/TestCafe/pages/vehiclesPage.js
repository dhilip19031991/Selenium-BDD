import { Selector } from "testcafe";
import xpath from '../utility/xpath-selector.js'

class VehiclesPage {
    constructor() {
        this.createVehicleBtn = Selector(xpath('//span[@id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PAVehiclesScreen:PAVehiclesPanelSet:VehiclesListDetailPanel_tb:Add-btnInnerEl"]'));
        this.VIN = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PAVehiclesScreen:PAVehiclesPanelSet:VehiclesListDetailPanel:VehiclesDetailsCV:PersonalAuto_VehicleDV:Vin_DV-inputEl"]');
        this.licenseStateDD = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PAVehiclesScreen:PAVehiclesPanelSet:VehiclesListDetailPanel:VehiclesDetailsCV:PersonalAuto_VehicleDV:LicenseState_DV-trigger-picker"]');
        this.licenseState = Selector(xpath('//li[text()="Arizona"]'));
        this.costNew = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PAVehiclesScreen:PAVehiclesPanelSet:VehiclesListDetailPanel:VehiclesDetailsCV:PersonalAuto_VehicleDV:CostNew_DV-inputEl"]');
        this.addBtn = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PAVehiclesScreen:PAVehiclesPanelSet:VehiclesListDetailPanel:VehiclesDetailsCV:PersonalAuto_AssignDriversDV:DriverPctLV_tb:AddDriver-btnInnerEl"]');
        this.addDriver = Selector('[id="SubmissionWizard:LOBWizardStepGroup:LineWizardStepSet:PAVehiclesScreen:PAVehiclesPanelSet:VehiclesListDetailPanel:VehiclesDetailsCV:PersonalAuto_AssignDriversDV:DriverPctLV_tb:AddDriver:0:Driver-textEl"]');
        this.nextBtn = Selector('[id="SubmissionWizard:Next-btnInnerEl"]');
        this.costNewErrorMsg = Selector(xpath('//div[@class="message"]'));
        this.licenseStateCalifornia = Selector(xpath('//li[text()="California"]'));
    }
}

export default new VehiclesPage();