import { Selector } from "testcafe";
import xpath from "../utility/xpath-selector";

class NewBillingPage {
    constructor() {
        this.leadtime = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:BillingPlanDetailDV:PaymentDueInterval-inputEl"]');
        this.nametxtbox = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:BillingPlanDetailDV:Name-inputEl"]');
        this.nonresponsiveleadtime = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:BillingPlanDetailDV:NonResponsivePaymentDueInterval-triggerWrap"]');
        this.businessdays = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:BillingPlanDetailDV:LeadTimeBusiness_option0-inputEl"]');
        this.calendardays = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:BillingPlanDetailDV:LeadTimeBusiness_option1-boxLabelEl"]');
        this.skipInstallmentfee_Yes = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:BillingPlanDetailDV:SkipInstallmentFees_true-boxLabelEl"]');
        this.skipInstallmentfee_No = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:BillingPlanDetailDV:SkipInstallmentFees_false-boxLabelEl"]');
        this.newBillingPlan = Selector(xpath('//a[@id="Admin:AdminMenuActions:AdminMenuActions_NewBillingPlan-itemEl"]'));
        this.reviewDisbursOver = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:BillingPlanDetailDV:DisbursementAmount-inputEl"]');
        this.DelayDisbursProcess = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:BillingPlanDetailDV:DelayDisbursement-inputEl"]');
        this.AutomaticDisbursementAmt = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:BillingPlanDetailDV:DisbursementOver-inputEl"]');
        this.updateBtn = Selector('[id="NewBillingPlan:NewBillingPlanDetailScreen:Update-btnInnerEl"]');
        this.BillingPlanTitle = Selector('[id="BillingPlans:BillingPlansScreen:ttlBar"]');
    }
}
export default new NewBillingPage();

