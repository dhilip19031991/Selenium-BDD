import { Selector } from "testcafe";

class QualificationPage {
    constructor() {
        this.nextBtn = Selector('[id="SubmissionWizard:Next-btnInnerEl"]');
    }
}

export default new QualificationPage();