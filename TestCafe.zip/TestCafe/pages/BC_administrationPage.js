import { Selector } from "testcafe";
import xpath from "../utility/xpath-selector";

class AdminstrationPage {
    constructor() {
        this.administrationTab = Selector(xpath('//a[@class="x-btn gw-top-menu-selected x-unselectable x-box-item x-toolbar-item x-btn-gw-top-menu-toolbar-small"]'));
        this.actions = Selector('[id="Admin:AdminMenuActions-btnEl"]');
        this.commissionPlan = Selector('id="Admin:AdminMenuActions:AdminMenuActions_NewCommissionPlan-itemEl"');
        this.newPaymentPlan = Selector(xpath('//a[@id="Admin:AdminMenuActions:AdminMenuActions_NewPaymentPlan-itemEl"]'));
        this.newBillingPlan = Selector(xpath('//a[@id="Admin:AdminMenuActions:AdminMenuActions_NewBillingPlan-itemEl"]'));
    }
}
export default new AdminstrationPage();