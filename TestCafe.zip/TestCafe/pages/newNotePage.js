import { Selector } from "testcafe";
import xpath from '../utility/xpath-selector.js'

class NewNotePage {
    constructor() {
        this.topicDD = Selector('[id="NewAccountNoteWorksheet:NewNoteScreen:NewNoteDV:Topic-inputEl"]');
        this.topic = Selector(xpath('//li[text()="General"]'));
        this.text = Selector('[id="NewAccountNoteWorksheet:NewNoteScreen:NewNoteDV:Text-inputEl"]');
        this.updateBtn = Selector('[id="NewAccountNoteWorksheet:NewNoteScreen:NewNoteScreen_UpdateButton-btnInnerEl"]');
    }
}

export default new NewNotePage();