import { Selector } from "testcafe";
import xpath from '../utility/xpath-selector.js'

class RiskAnalysisPage {
    constructor() {
        this.MVRTab = Selector('[id="SubmissionWizard:Job_RiskAnalysisScreen:RiskAnalysisCV:MotorVehicleRecordTab-btnInnerEl"]');
        this.MVRStatus = Selector(xpath('//div[@id="SubmissionWizard:Job_RiskAnalysisScreen:RiskAnalysisCV-body"]//div[text()="Received"]'));
        this.nextBtn = Selector('[id="SubmissionWizard:Next-btnInnerEl"]');
        this.RiskAnalysisText = Selector('[id="SubmissionWizard:Job_RiskAnalysisScreen:0"]');
        this.stategaragingUW = Selector ('[class="x-grid-checkcolumn "]');
        this.rejectBtn = Selector ('[id="SubmissionWizard:Job_RiskAnalysisScreen:RiskAnalysisCV:RiskEvaluationPanelSet:Reject-btnInnerEl"]');
   
    }
}

export default new RiskAnalysisPage();