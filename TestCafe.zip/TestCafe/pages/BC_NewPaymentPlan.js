import { Selector } from "testcafe";
import xpath from "../utility/xpath-selector";

class NewPaymentPlan {
    constructor() {
        this.Name = Selector('[id="NewPaymentPlanWizard:NewPaymentPlan_FirstStepScreen:Name-inputEl"]');
        this.PaymentIntervalDrpDwn = Selector('[id="NewPaymentPlanWizard:NewPaymentPlan_FirstStepScreen:PaymentInterval-inputEl"]');
        this.IsReporting_Yes = Selector('[id="NewPaymentPlanWizard:NewPaymentPlan_FirstStepScreen:Reporting_true-boxLabelEl"]');
        this.FeeAmt = Selector('[id="NewPaymentPlanWizard:NewPaymentPlan_FirstStepScreen:FeeAmount-inputEl"]');
        this.NextBtn = Selector('[id="NewPaymentPlanWizard:Next-btnInnerEl"]');
        this.PaymentUnterval_Monthly= Selector(xpath('//li[text()="Monthly"]'));
        
    }
}
export default new NewPaymentPlan();