const { fixture, test } = require("testcafe");
import { Selector } from 'testcafe';
import data from '../datas/data.json';
import lp from '../pages/loginPage.js';
import dp from '../pages/dashboardPage.js';
import nsp from '../pages/newSubmissionPage.js';
import asp from '../pages/accSummaryPage.js';
import nahp from '../pages/newAccHolderPage.js'
import { generateRandomNumber, generateRandomString, getAccNumPerson } from '../utility/helper.js';

fixture('Change Account Holder')
    .page(data.URL);

test('Change Account Holder - New Person', async t => {

    await t
        .maximizeWindow()
        .typeText(lp.userName, data.userName)
        .typeText(lp.password, data.password)
        .click(lp.loginBtn)
        .expect(dp.successMsg.innerText).contains('My Activities')
        .click(dp.actionsTab)
        .click(dp.newSubmission)
        .typeText(nsp.accNum, await getAccNumPerson())
        .click(nsp.org)
        .click(nsp.accName)
        .click(asp.changeAccHolderBtn)
        .click(asp.newPersonBtn)
        .typeText(nahp.firstName, generateRandomString(2))
        .typeText(nahp.lastName, generateRandomNumber(1))
        .typeText(nahp.zipcode, '85001')
        .typeText(nahp.address1, '789 ZZZ')
        .click(nahp.addressTypeDD)
        .click(nahp.addressType)
        .click(nahp.updateBtn);
});