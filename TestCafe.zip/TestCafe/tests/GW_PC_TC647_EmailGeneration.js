const { fixture, test } = require("testcafe");
import { Selector } from 'testcafe';
import data from '../datas/data.json';
import lp from '../pages/loginPage.js';
import dp from '../pages/dashboardPage.js';
import nsp from '../pages/newSubmissionPage.js';
import asp from '../pages/accSummaryPage.js';
import nep from '../pages/newEmailPage.js'
import { getAccNumPerson } from '../utility/helper.js';

fixture('Email Generation')
    .page(data.URL);

test('Email Generation in Existing Account', async t => {

    await t
        .maximizeWindow()
        .typeText(lp.userName, data.userName)
        .typeText(lp.password, data.password)
        .click(lp.loginBtn)
        .expect(dp.successMsg.innerText).contains('My Activities')
        .click(dp.actionsTab)
        .click(dp.newSubmission)
        .typeText(nsp.accNum, await getAccNumPerson())
        .click(nsp.org)
        .click(nsp.accName)
        .click(asp.actions)
        .click(asp.newEmail)
        .doubleClick(nep.name)
        .pressKey('S+A+r+a+l')
        .doubleClick(nep.email)
        .pressKey('s+a+r+a+l+Shift+2+g+m+a+i+l+.+c+o+m')
        .typeText(nep.subject, 'RE Email')
        .typeText(nep.body, 'Hi Guidewire')
        .click(nep.sendBtn);
});