const { fixture, test } = require("testcafe");
import { Selector } from 'testcafe';
import data from '../datas/data.json';
import lp from '../pages/loginPage.js';
import { generateRandomString, generateRandomNumber } from '../utility/helper.js';
import BC_adminPage from '../pages/BC_administrationPage.js';
import BC_NewBillPage from '../pages/BC_NewBillingPage.js';
import BC_NewPaymtPlan from '../pages/BC_NewPaymentPlan';
import BC_installTreat from '../pages/BC_installmentTreatment.js'
import BC_commissionPlan from '../pages/BC_commissionPlan.js';
export let AdminMenuActions_NewCommissionPlan;

fixture(`BC Administration data Update_New Commission Plan`)
    .page(data.BC_URL);

test('create a New Commission Plan in Actions menu from Administration Tab', async t => {

    await t
        .maximizeWindow()
        .typeText(lp.userName, data.userName)
        .typeText(lp.password, data.password)
        .click(lp.loginBtn)
        //.click(BC_adminPage.administrationTab)
        .click(BC_adminPage.actions)
        .click(BC_adminPage.commissionPlan)
        .typeText(BC_commissionPlan.name,generateRandomString(6))
        .typeText(BC_commissionPlan.primary,generateRandomString(5))
        .typeText(BC_commissionPlan.secondary,generateRandomString(5))
        .typeText(BC_commissionPlan.referrer,generateRandomString(5))
        .click(BC_commissionPlan.eancommissiondrpdwn)
        .click(BC_commissionPlan.eanCommissionOption)
        .click(BC_commissionPlan.UpdtBtn)
        .wait(3000)
      
    });