const { fixture, test } = require("testcafe");
import data from '../datas/data.json';
import lp from '../pages/loginPage.js';
import dp from '../pages/dashboardPage.js';
import nsp from '../pages/newSubmissionPage.js';
import asp from '../pages/accSummaryPage.js';
import eap from '../pages/editAccPage.js';
import { getAccNumPerson } from '../utility/helper.js';


fixture(`Update Account`)
    .page(data.URL);

test('Account Details Updation', async t => {

    await t
        .maximizeWindow()
        .typeText(lp.userName, data.userName)
        .typeText(lp.password, data.password)
        .click(lp.loginBtn)
        .expect(dp.successMsg.innerText).contains('My Activities')
        .click(dp.actionsTab)
        .click(dp.newSubmission)
        .typeText(nsp.accNum, await getAccNumPerson())
        .click(nsp.org)
        .click(nsp.accName)
        .click(asp.editAccBtn)
        .typeText(eap.address1, '234 BBB', { replace: true })
        .click(eap.updateBtn)
});
