const { fixture, test } = require("testcafe");
import { Selector } from 'testcafe';
import data from '../datas/data.json';
import lp from '../pages/loginPage.js';
import dp from '../pages/dashboardPage.js';
import nsp from '../pages/newSubmissionPage.js';
import asp from '../pages/accSummaryPage.js';
import nnp from '../pages/newNotePage.js'
import ac from '../pages/AccountCreationLocators.js';
import ai from '../pages/accInfoPage.js';
import ca from '../pages/createAccPage.js';
import orgPage from '../pages/OrganizationsPage.js'
import offer from '../pages/offeringsPage.js';
import { generateRandomNumber,generateRandomString } from '../utility/helper';

fixture('Withdraw Account')
    .page(data.URL);

test('Withdrawing an Existing Account', async t => {

    await t
        .maximizeWindow()
        .typeText(lp.userName, data.userName)
        .typeText(lp.password, data.password)
        .click(lp.loginBtn)
        .expect(dp.successMsg.innerText).contains('My Activities')
        .click(ac.clickActionsTab)
        .click(ac.clickNewAccountBtn)
        .typeText(ai.companyName,generateRandomString(1))
        .click(ai.searchBtn)
        .click(ai.createNewAcc)
        .click(ai.personBtn)
        .typeText(ca.firstname,generateRandomString(4))
        .typeText(ca.lastname,generateRandomString(5))
        .typeText(ca.address1,'s')
        .typeText(ca.zipCode,'17073')
        .typeText(ca.city,'NEW PROVIDENCE')
        .wait(3000)
        .click(ca.state)
        .click(ca.state)
        .click(ca.stateDD)
        .click(ca.addressTypeDD)
        .click(ca.addressType)
        .typeText(ca.ProducerSelect,'enigma')
        .click(ca.searchIcon)
        .typeText(orgPage.OrgName,'enigma')
        .click(orgPage.SearchBtn)
        .click(orgPage.OrgSelect)
        .click(ca.pcDDIcon)
        .click(ca.producerCode)
        .click(ca.updateBtn)
        .click(asp.actions)
        .click(asp.withdrawAcc)
        .wait(3000)
    console.log('Account Status for Withdrawn TestCase is ' + await Selector(asp.accStatus).innerText)
});