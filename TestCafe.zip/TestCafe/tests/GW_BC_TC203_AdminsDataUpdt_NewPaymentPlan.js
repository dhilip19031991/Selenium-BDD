const { fixture, test } = require("testcafe");
import { Selector } from 'testcafe';
import data from '../datas/data.json';
import lp from '../pages/loginPage.js';
import { generateRandomString, generateRandomNumber } from '../utility/helper.js';
import BC_adminPage from '../pages/BC_administrationPage.js';
import BC_NewBillPage from '../pages/BC_NewBillingPage.js';
import BC_NewPaymtPlan from '../pages/BC_NewPaymentPlan';
import BC_installTreat from '../pages/BC_installmentTreatment.js';
export let AdminMenuActions_NewPaymentPlan;

fixture(`BC Administration data Update_New Payment Plan`)
    .page(data.BC_URL);

test('create a New Payment plan in Actions menu from Administration Tab', async t => {

    await t
        .maximizeWindow()
        .typeText(lp.userName, data.userName)
        .typeText(lp.password, data.password)
        .click(lp.loginBtn)
        //.click(BC_adminPage.administrationTab)
        .click(BC_adminPage.actions)
        .click(BC_adminPage.newPaymentPlan)
        .typeText(BC_NewPaymtPlan.Name,generateRandomString(7))
        .click(BC_NewPaymtPlan.IsReporting_Yes)
        .click(BC_NewPaymtPlan.PaymentIntervalDrpDwn)
        .click(BC_NewPaymtPlan.PaymentUnterval_Monthly)
        .typeText(BC_NewPaymtPlan.FeeAmt,generateRandomNumber(3))
        .click(BC_NewPaymtPlan.NextBtn)
        .typeText(BC_installTreat.maxinstallments,generateRandomNumber(1))
        .typeText(BC_installTreat.downpayment,generateRandomNumber(2))
        .typeText(BC_installTreat.invoiced,generateRandomNumber(6))
        .click(BC_installTreat.finish)
        .wait(3000)
    });