const { fixture, test } = require("testcafe");
import { Selector } from 'testcafe';
import { generateRandomString, generateRandomNumber, setAccNumPerson } from '../utility/helper.js';
import data from '../datas/data.json';
import lp from '../pages/loginPage.js';
import dp from '../pages/dashboardPage.js';
import aip from '../pages/accInfoPage.js';
import cap from '../pages/createAccPage.js'
import op from '../pages/orgPage.js';
import asp from '../pages/accSummaryPage.js';

export let accNoPerson;

fixture(`Account Creation`)
    .page(data.URL);

test('Personal Account Creation', async t => {

    await t.maximizeWindow();
    await t.typeText(lp.userName, data.userName);
    await t.typeText(lp.password, data.password);
    await t.click(lp.loginBtn);
    await t.expect(dp.successMsg.innerText).contains('My Activities');
    await t.click(dp.actionsTab);
    await t.click(dp.newAccount);
    await t.expect(aip.successMsg.innerText).contains('Enter Account Information');
    await t.typeText(aip.firstName, generateRandomString(4));
    await t.typeText(aip.lastName, generateRandomNumber(3));
    await t.click(aip.searchBtn);
    await t.expect(aip.checkPoint.innerText).contains('The search returned zero results.');
    await t.click(aip.createNewAcc);
    await t.click(aip.personBtn);
    await t.expect(cap.successMsg.innerText).contains('Create account');
    await t.typeText(cap.zipCode, '85001');
    await t.typeText(cap.address1, '123 AAA');
    await t.click(cap.addressTypeDD);
    await t.click(cap.addressType);
    await t.click(cap.orgDD);
    await t.expect(op.successMsg.innerText).contains('Organizations');
    await t.typeText(op.orgName, 'Enigma');
    await t.click(op.searchBtn);
    await t.click(op.selectBtn);
    await t.click(cap.pcDDIcon);
    await t.click(cap.producerCode);
    await t.click(cap.updateBtn);
    const accNoPerson = await Selector(asp.accNoTxt).innerText;
    //accNoPerson = await getAccNum();
    await setAccNumPerson(accNoPerson);
    console.log('Person Account No. is : ' + accNoPerson);
});