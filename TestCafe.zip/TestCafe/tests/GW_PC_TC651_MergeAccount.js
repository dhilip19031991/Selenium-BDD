import { Selector } from 'testcafe';
import lp from '../pages/loginPage';
import data from '../datas/data.json';
import ac from '../pages/AccountCreationLocators.js';
import ai from '../pages/accInfoPage.js';
import ca from '../pages/createAccPage.js';
import orgPage from '../pages/OrganizationsPage.js'
import accSum from '../pages/accSummaryPage.js';
import newSub from '../pages/newSubmissionPage.js';
import offer from '../pages/offeringsPage.js';
import dp from '../pages/driversPage.js';
import { generateRandomNumber,generateRandomString } from '../utility/helper';
import vp from '../pages/vehiclesPage.js';
import pac from '../pages/PAcoveragesPage.js';
import rap from '../pages/riskAnalysisPage.js';
import prp from '../pages/policyReviewPage.js';
import pp from '../pages/paymentPage.js';
import sbp from '../pages/submissionBoundPage.js';

fixture(`Merging Account`) 
    .page(data.URL);

    test ('Merge Account in PolicyCenter',async t=> {
       await t.maximizeWindow();
       await t.typeText(lp.userName,data.userName);
       await t.typeText(lp.password,data.password);
       await t.click(lp.loginBtn);
       await t.click(ac.clickActionsTab);
       await t.click(ac.clickNewAccountBtn);
       await t.typeText(ai.companyName,generateRandomString(1));
       await t.click(ai.searchBtn);
       await t.click(ai.createNewAcc);
       await t.click(ai.companyBtn);
       await t.typeText(ca.address1,'170 AA');
       await t.typeText(ca.zipCode,'17073');
       await t.typeText(ca.city,'NEW PROVIDENCE');
       await t.wait(3000);
       await t.click(ca.state)
       await t.click(ca.state)
       await t.click(ca.stateDD);
       await t.click(ca.addressTypeDD);
       await t.click(ca.addressType);
       await t.typeText(ca.ProducerSelect,'enigma');
       await t.click(ca.searchIcon);
       await t.typeText(orgPage.OrgName,'enigma');
       await t.click(orgPage.SearchBtn);
       await t.click(orgPage.OrgSelect);
       await t.click(ca.pcDDIcon);
       await t.click(ca.producerCode);
       await t.click(ca.updateBtn);
       await t.click(accSum.actions);
       await t.click(accSum.mergeToAccount);
       await t.wait(3000);
       await t.typeText(accSum.accNumTxtBx,'6507712026');
       await t.click(accSum.searchBtn);
       await t.wait(3000);
       await t.click(accSum.selectPolicy);
       //await t.expect(accSum.infoText.partialText).contains('All information from account');
      // await t.expect(accSum.accountText.partialText).contains('Account #* will be removed.');
       await t.click(accSum.mergeaccountBtn);
       //await t.click(accSum.mergeOkPopup);
       await t.wait(3000);
    });