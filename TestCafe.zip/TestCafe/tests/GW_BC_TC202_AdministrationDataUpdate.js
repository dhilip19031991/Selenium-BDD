const { fixture, test } = require("testcafe");
import { Selector } from 'testcafe';
import data from '../datas/data.json';
import lp from '../pages/loginPage.js';
import { generateRandomString, generateRandomNumber } from '../utility/helper.js';
import BC_adminPage from '../pages/BC_administrationPage.js';
import BC_NewBillPage from '../pages/BC_NewBillingPage.js';
export let AdminstrationPage;

fixture(`BC Administration Page data Update`)
    .page(data.BC_URL);

test('create a New Billing plan in Actions menu from Administration Tab', async t => {

    await t
        .maximizeWindow()
        .typeText(lp.userName, data.userName)
        .typeText(lp.password, data.password)
        .click(lp.loginBtn)
        //.click(BC_adminPage.administrationTab)
        .click(BC_adminPage.actions)
        .click(BC_adminPage.newBillingPlan) 
        .typeText(BC_NewBillPage.nametxtbox,generateRandomString(7))
        .wait(3000)
        .typeText(BC_NewBillPage.leadtime,generateRandomNumber(2))
        .wait(3000)
        .typeText(BC_NewBillPage.leadtime,generateRandomNumber(2))
        .typeText(BC_NewBillPage.nonresponsiveleadtime,generateRandomNumber(2))
        .click(BC_NewBillPage.businessdays)
        .click(BC_NewBillPage.skipInstallmentfee_Yes)
        .typeText(BC_NewBillPage.reviewDisbursOver,generateRandomNumber(4))
        .typeText(BC_NewBillPage.DelayDisbursProcess,generateRandomNumber(2))
        .typeText(BC_NewBillPage.AutomaticDisbursementAmt,generateRandomNumber(3))
        .click(BC_NewBillPage.updateBtn)
        console.log('New Billing plan in Actions menu  from Administration Tab is created')
    
    });