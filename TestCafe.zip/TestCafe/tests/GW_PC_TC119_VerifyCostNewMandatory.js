const { fixture, test } = require("testcafe");
import { Selector } from 'testcafe';
import { generateRandomString, generateRandomNumber } from '../utility/helper.js';
import data from '../datas/data.json';
import lp from '../pages/loginPage.js';
import dp from '../pages/dashboardPage.js';
import aip from '../pages/accInfoPage.js';
import op from '../pages/orgPage.js';
import nsp from '../pages/newSubmissionPage.js';
import cap from '../pages/createAccPage.js'
import asp from '../pages/accSummaryPage.js';
import lobp from '../pages/LOBPage.js'
import offp from '../pages/offeringsPage.js'
import qp from '../pages/qualificationsPage.js'
import pip from '../pages/policyInfoPage.js'
import drp from '../pages/driversPage.js'
import vp from '../pages/vehiclesPage.js'
import pacp from '../pages/PAcoveragesPage.js'
import rap from '../pages/riskAnalysisPage.js'
import prp from '../pages/policyReviewPage.js'
import qop from '../pages/quotePage.js'
import sbp from '../pages/submissionBoundPage.js'
import psp from '../pages/policySummaryPage.js'

export let accNoPerson;

fixture(`Cost New Mandatory`)
    .page(data.URL);

test('Verifying Cost New is Mandatory in Vehicle Screen for PA polciy', async t => {

    await t
        .maximizeWindow()
        .typeText(lp.userName, data.userName)
        .typeText(lp.password, data.password)
        .click(lp.loginBtn)
        .expect(dp.successMsg.innerText).contains('My Activities')
        .click(dp.actionsTab)
        .click(dp.newAccount)
        .expect(aip.successMsg.innerText).contains('Enter Account Information')
        .typeText(aip.firstName, generateRandomString(4))
        .typeText(aip.lastName, generateRandomNumber(3))
        .click(aip.searchBtn)
        .expect(aip.checkPoint.innerText).contains('The search returned zero results.')
        .click(aip.createNewAcc)
        .click(aip.personBtn)
        .expect(cap.successMsg.innerText).contains('Create account')
        .typeText(cap.zipCode, '85001')
        .typeText(cap.address1, '123 AAA')
        .click(cap.addressTypeDD)
        .click(cap.addressType)
        .click(cap.orgDD)
        .expect(op.successMsg.innerText).contains('Organizations')
        .typeText(op.orgName, 'Enigma')
        .click(op.searchBtn)
        .click(op.selectBtn)
        .click(cap.pcDDIcon)
        .click(cap.producerCode)
        .click(cap.updateBtn)
        //const accNo =await Selector(asp.accNoTxt).innerText
        .click(asp.actions)
        .click(asp.newSubmission)
        .click(lobp.btnSelectPA)
        .click(offp.offeringsDD)
        .click(offp.offeringsType)
        .click(offp.nextBtn)
        .click(qp.nextBtn)
        .click(pip.nextBtn)
        .click(drp.addBtn).click(drp.existingDriver).click(drp.accHolder)
        .click(drp.dob).pressKey('ctrl+a delete').typeText(drp.dob, '01/29/1987')
        .click(drp.licenseNo).pressKey('ctrl+a delete').typeText(drp.licenseNo, 'A98765432')
        .click(drp.licenseStateDD).click(drp.licenseState)
        .click(drp.rolesTab)
        .click(drp.yearFirstLicensed).pressKey('ctrl+a delete').typeText(drp.yearFirstLicensed, '2019')
        .click(drp.accidentsNoPL).click(drp.accidentsNoPLValue)
        .click(drp.accidentsNoAL).click(drp.accidentsNoALValue)
        .click(drp.violationsNoPL).click(drp.violationsNoPLValue)
        .click(drp.violationsNoAL).click(drp.violationsNoALValue)
        .click(drp.radioBtn).click(drp.retrieveMVRBtn)
        .click(drp.nextBtn)
        .click(vp.createVehicleBtn)
        .typeText(vp.VIN, '1LNHM94RX9G676671')
        .click(vp.costNew)
        .click(vp.licenseStateDD).click(vp.licenseState)
        .click(vp.addBtn).click(vp.addDriver)
        .click(vp.nextBtn)
    console.log('Error Message for without passing Cost New Value is : ' + await Selector(vp.costNewErrorMsg).innerText)
    await t
        .typeText(vp.costNew, '34567')
        .click(vp.nextBtn)
        .click(pacp.nextBtn)
        .click(rap.nextBtn)
        .click(prp.quoteBtn)
        .click(qop.bindOptionsDD).click(qop.issuePolicyBtn).click(qop.okBtn)
        .click(sbp.viewPolicy)
    console.log('Policy No. of PA Policy in Cost New Verification is : ' + await Selector(psp.policyNo).innerText)
});